package application;

public class Loggato 
{
	public static int Loggato=0;//0=nessuno,1=admin,2=cliente

	public static void setVar(int n)
	{
		Loggato=n;
	}
}
